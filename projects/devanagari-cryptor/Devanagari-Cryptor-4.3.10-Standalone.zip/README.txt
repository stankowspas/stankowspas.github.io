Devanagari Cryptor 4.3.10 — SINGLE-FILE TEST BUILD

Open app-4.3.10-standalone.html with a modern browser.
The archive engine, WebAssembly binary and archive interface are embedded in this HTML; the archive mode needs no separate folders, network connections or local HTTP server.
For the encryption modes to work, the Web Crypto API must be available in a secure browsing context. Use HTTPS or http://localhost if your browser disables Web Crypto on file:/// or about:blank.

Archive mode: ZIP, 7z, TAR, TAR.GZ, TAR.BZ2 and TAR.XZ creation; supported format extraction includes ZIP, RAR and 7z subject to browser and libarchive codec support.
The application does not create RAR files or password-protected archives. Password-protected archive extraction depends on the format and library support.

Prototype status: engine bootstrap tested in Chromium with an about:blank document using a classic Blob worker and a WebAssembly Blob. Syntax and embedded asset integrity checked. Actual ZIP/7z/RAR end-to-end file processing remains to be confirmed in the user's browser.

Unmodified existing modes: Classic, Secure Text, File Protection. Four color themes and 12 UI languages preserved.

Components: Devanagari Cryptor © Spas Stankov (MIT), libarchive.js 2.0.2 (MIT) / libarchive (BSD-style); bundled worker includes Apache-2.0 Comlink. Retain third-party licenses in archive-vendor if redistributing a modified build.
