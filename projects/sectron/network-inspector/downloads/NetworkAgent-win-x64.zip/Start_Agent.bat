@echo off
setlocal
title NETWORK INSPECTOR v2 - Windows Agent
cd /d "%~dp0"
if not exist "NetworkAgent.dll" goto missing_files
set "DOTNET_EXE="
if exist "%LOCALAPPDATA%\Microsoft\dotnet\dotnet.exe" set "DOTNET_EXE=%LOCALAPPDATA%\Microsoft\dotnet\dotnet.exe"
if not defined DOTNET_EXE where dotnet.exe >nul 2>nul && set "DOTNET_EXE=dotnet.exe"
if not defined DOTNET_EXE goto missing_runtime
"%DOTNET_EXE%" --list-runtimes | findstr /B /C:"Microsoft.AspNetCore.App 10." >nul
if errorlevel 1 goto missing_runtime
echo.
echo NETWORK INSPECTOR v2 - starting local agent...
echo Default address: http://127.0.0.1:5188
echo Keep this window open while using the application.
echo.
"%DOTNET_EXE%" NetworkAgent.dll
set "EXIT_CODE=%ERRORLEVEL%"
echo.
echo Network Agent stopped. Exit code: %EXIT_CODE%
echo If port 5188 is occupied, close the other local Network Agent before retrying.
echo.
pause
exit /b %EXIT_CODE%
:missing_runtime
echo .NET 10 ASP.NET Core Runtime is required.
echo https://dotnet.microsoft.com/en-us/download/dotnet/10.0
pause
exit /b 1
:missing_files
echo NetworkAgent.dll was not found. Extract the complete ZIP archive first.
pause
exit /b 1
